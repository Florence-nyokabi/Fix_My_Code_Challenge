const labelInstance = (
  <div>
    <h1>Label <Label>New</Label></h1>
    <h2>Label <Label>New</Label></h2>
    <h3>Label <Label>New</Label></h3>
    <h4>Label <Label>New</Label></h4>
    <h5>Label <Label>New</Label></h5>
    <p>Label <Label>New</Label></p>
  </div>
);

React.render(labelInstance, mountNode);
