# React Blog

Simple React Blog

### How to run 

1. Install Gulp - `npm install -g gulp`
2. `npm install` to install dependencies.
3. Run `gulp build-all` to build the code.
4. Run `gulp nodemon` to start the server.
5. Go to http://localhost:5000/
