//This file was auto generated. Updating it will have no effect
var JsxIncludes = {};
JsxIncludes["/static/jsx/react-components-example.jsx"] = require("../../public/static/jsx/react-components-example.jsx");

module.exports = JsxIncludes;
